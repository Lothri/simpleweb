## Simple Web

# Description
This is a simple web browser created in Python

# Dependencies
It needs the requests library
